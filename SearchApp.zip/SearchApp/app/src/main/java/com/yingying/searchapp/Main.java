package com.yingying.searchapp;

import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Yingying Xia
 */
public class Main {

    public static void main(String[] args) throws IOException {
       // AdminProfile ap = new AdminProfile("Yingying","Xia","Xiadog");
      //  new saveRestaurant("Restaurant.csv",ap,"Subway","123 abc","39485094","5" );
        
        
     //   hashmap hm = new hashmap("Userpass.csv", "Restaurant.csv");
        
     //   System.out.println(hm.restaurant.get("Subway").rAddress);
        //System.out.println(hm.restaurant.get("Taco Bell").rAddress);
      
        
        
        
        /*DisplayResRank rank = new DisplayResRank (hm.restaurant);
         Restaurant [] ranking = rank.displayHighToLowRanking(hm.restaurant);
         for (int i = 0; i < ranking.length; i++) {
             System.out.println(ranking[i].getName() + ranking[i].getAverageRating());
        }*/
    }
}
